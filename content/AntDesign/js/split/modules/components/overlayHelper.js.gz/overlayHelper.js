import { domInfoHelper, eventHelper, domManipulationHelper } from '../dom/exports';
import { Overlay } from './overlay';
import { state } from '../stateProvider';
export class overlayHelper {
    static addOverlayToContainer(blazorId, overlaySelector, triggerSelector, placement, containerSelector, triggerBoundyAdjustMode, triggerIsWrappedInDiv, triggerPrefixCls, verticalOffset, horizontalOffset, arrowPointAtCenter, overlayTop, overlayLeft) {
        const overlayElement = domInfoHelper.get(overlaySelector);
        const containerElement = domInfoHelper.get(containerSelector);
        const triggerElement = domInfoHelper.get(triggerSelector);
        if (!domManipulationHelper.addElementTo(overlaySelector, containerElement)) {
            console.log("Failed to add overlay. Details:", {
                triggerPrefixCls: triggerPrefixCls,
                overlaySelector: overlaySelector,
                containerElement: containerElement
            });
            return null;
        }
        let overlayPresets;
        if (overlayTop || overlayLeft) {
            overlayPresets = { x: overlayLeft, y: overlayTop };
        }
        let overlayConstraints = {
            verticalOffset: verticalOffset,
            horizontalOffset: horizontalOffset,
            arrowPointAtCenter: arrowPointAtCenter
        };
        let overlay = new Overlay(blazorId, overlayElement, containerElement, triggerElement, placement, triggerBoundyAdjustMode, triggerIsWrappedInDiv, triggerPrefixCls, overlayConstraints);
        //register object in store, so it can be retrieved during update/dispose
        this.overlayRegistry[blazorId] = overlay;
        return overlay.calculatePosition(false, true, overlayPresets);
    }
    static updateOverlayPosition(blazorId, overlaySelector, triggerSelector, placement, containerSelector, triggerBoundyAdjustMode, triggerIsWrappedInDiv, triggerPrefixCls, verticalOffset, horizontalOffset, arrowPointAtCenter, overlayTop, overlayLeft) {
        const overlay = this.overlayRegistry[blazorId];
        if (overlay) {
            let overlayPresets;
            if (overlayTop || overlayLeft) {
                overlayPresets = { x: overlayLeft, y: overlayTop };
            }
            return overlay.calculatePosition(false, false, overlayPresets);
        }
        else {
            //When page is slow, it may happen that rendering of an overlay may not happen, even if 
            //blazor thinks it did happen. In such a case, when overlay object is not found, just try
            //to render it again.
            return overlayHelper.addOverlayToContainer(blazorId, overlaySelector, triggerSelector, placement, containerSelector, triggerBoundyAdjustMode, triggerIsWrappedInDiv, triggerPrefixCls, verticalOffset, horizontalOffset, arrowPointAtCenter, overlayTop, overlayLeft);
        }
    }
    static deleteOverlayFromContainer(blazorId) {
        const overlay = this.overlayRegistry[blazorId];
        if (overlay) {
            overlay.dispose();
            delete this.overlayRegistry[blazorId];
        }
    }
    static addPreventEnterOnOverlayVisible(element, overlayElement) {
        if (element && overlayElement) {
            let dom = domInfoHelper.get(element);
            if (dom) {
                state.eventCallbackRegistry[element.id + "keydown:Enter"] = (e) => eventHelper.preventKeyOnCondition(e, "enter", () => overlayElement.offsetParent !== null);
                dom.addEventListener("keydown", state.eventCallbackRegistry[element.id + "keydown:Enter"], false);
            }
        }
    }
    static removePreventEnterOnOverlayVisible(element) {
        if (element) {
            let dom = domInfoHelper.get(element);
            if (dom) {
                dom.removeEventListener("keydown", state.eventCallbackRegistry[element.id + "keydown:Enter"]);
                state.eventCallbackRegistry[element.id + "keydown:Enter"] = null;
            }
        }
    }
}
overlayHelper.overlayRegistry = {};
